/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */




/**
 *
 * @author tucker.stone061
 */

    
/**
 * Represents a bush. Bushes don't do anything, they're just there.
 */
public class Bush {
}
